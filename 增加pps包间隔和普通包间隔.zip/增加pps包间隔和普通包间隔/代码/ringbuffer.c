
/*
 * Important:
 *
 * This file using "UTF-8 65001 with BOM" coding.
 * Choose editor coding if you could not see words below.
 *
 * �����ط��˵����룬�༭��ʹ����������ſ��õ���仰����
 * �������ǹ�����༭�����ģ���һ���ʶ��ͷ������ɾ����
 */

 /*
  * File      : ringbuffer.c
  * This file is customized ringbuffer for multi thread interface implementaion file
  * COPYRIGHT (C) 2019 zmvision
  *
  * Change Logs:
  * Date           Author       Notes
  * 2019-03-24     fengyong    first version
  * 2024-03-18     fengyong    �ع����룬�Ż�Ԫ�ؽṹ��2��������
  * 2024-03-20     fengyong    ����fifo�ռ䡢�����ĸ����ӿ�;����ע��
  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <assert.h>

#include "ringbuffer.h"

#define rb_min(X, Y)				\
	({ typeof(X) __x = (X);			\
		typeof(Y) __y = (Y);		\
		(__x < __y) ? __x : __y; })

static inline int is_power_of_2(uint32_t n)
{
	return (n != 0 && ((n & (n - 1)) == 0));
}

static inline uint32_t rounddown_pow_of_two(uint32_t n)
{
	n |= n >> 1; n |= n >> 2; n |= n >> 4; n |= n >> 8; n |= n >> 16;
	return (n + 1) >> 1;
}

ring_buffer_t* ringbuffer_create(uint32_t size, uint32_t esize)
{
	ring_buffer_t* rb = NULL;
	uint8_t* buf = NULL;
	uint32_t buf_size = 0;

	rb = (ring_buffer_t*)malloc(sizeof(*rb));
	if (rb == NULL) {
		goto exit;
	}

	memset(rb, 0, sizeof(*rb));

	size /= esize;

	if (!is_power_of_2(size)) {
		size = rounddown_pow_of_two(size);
	}

	buf_size = esize * size;
	buf = (uint8_t*)malloc(buf_size);
	if (NULL == buf) {
		free(rb);
		rb = NULL;
		goto exit;
	}

	memset(buf, 0, buf_size);

	rb->in = 0;
	rb->out = 0;
	rb->esize = esize;
	rb->data = buf;

	if (size < 1) {
		rb->mask = 0;
		free(rb);
		free(buf);
		rb = NULL;
		buf = NULL;
		return NULL;
	}

	rb->mask = size - 1;

exit:
	return rb;
}

void ringbuffer_destory(ring_buffer_t* rb)
{
	if (rb->data) {
		free(rb->data);
	}

	if (rb) {
		free(rb);
	}

	rb = NULL;

	return;
}

static void ringbuffer_copy_in(ring_buffer_t* rb, const void* src, uint32_t len, uint32_t off)
{
	uint32_t size = rb->mask + 1;
	uint32_t esize = rb->esize;
	uint32_t l;

	off &= rb->mask;
	if (esize != 1) {
		off *= esize;
		size *= esize;
		len *= esize;
	}
	l = rb_min(len, size - off);

	memcpy(rb->data + off, src, l);
	memcpy(rb->data, src + l, len - l);
	/*
	 * make sure that the data in the fifo is up to date before
	 * incrementing the fifo->in index counter
	 */
	__sync_synchronize();
}

static inline unsigned int ringbuffer_unused(ring_buffer_t* rb)
{
	return (rb->mask + 1) - (rb->in - rb->out);
}

uint32_t ringbuffer_put(ring_buffer_t* rb, const void* buf, uint32_t len)
{
	uint32_t l;
	uint32_t count = (len >= rb->esize) ? 1 : 1;

	l = ringbuffer_unused(rb);
	if (count > l)
		count = l;

	ringbuffer_copy_in(rb, buf, count, rb->in);
	rb->in += count;

	return count;
}

static void ringbuffer_copy_out(ring_buffer_t* rb, void* dst, uint32_t len, uint32_t off)
{
	uint32_t size = rb->mask + 1;
	uint32_t esize = rb->esize;
	uint32_t l;

	off &= rb->mask;
	if (esize != 1) {
		off *= esize;
		size *= esize;
		len *= esize;
	}
	l = rb_min(len, size - off);

	memcpy(dst, rb->data + off, l);
	memcpy(dst + l, rb->data, len - l);
	/*
	 * make sure that the data is copied before
	 * incrementing the fifo->out index counter
	 */
	__sync_synchronize();
}

static uint32_t ringbuffer_out_peek(ring_buffer_t* rb, void* buf, uint32_t len)
{
	uint32_t l;

	l = rb->in - rb->out;
	if (len > l)
		len = l;

	ringbuffer_copy_out(rb, buf, len, rb->out);
	return len;
}

uint32_t ringbuffer_get(ring_buffer_t* rb, void* buf, uint32_t len)
{
	uint32_t count = (len >= rb->esize) ? 1 : 1;

	count = ringbuffer_out_peek(rb, buf, count);
	rb->out += count;
	return count;
}

uint32_t ringbuffer_len(ring_buffer_t* rb)
{
	return rb->in - rb->out;
};

uint32_t ringbuffer_cap(ring_buffer_t* rb)
{
	return rb->mask + 1;
};

uint32_t ringbuffer_avail(ring_buffer_t* rb)
{
	return ringbuffer_cap(rb) - ringbuffer_len(rb);
};

bool ringbuffer_is_full(ring_buffer_t* rb)
{
	return ringbuffer_len(rb) > rb->mask;
};

bool ringbuffer_is_empty(ring_buffer_t* rb)
{
	return rb->in == rb->out;
};

void ringbuffer_reset(ring_buffer_t* rb)
{
	rb->in = 0;
	rb->out = 0;
}
